from collections.abc import Iterator
from typing import Any, Sequence, assert_type
from unittest import TestCase

import pytest

from verysimpletree import (
    ChildNotFoundError,
    HomogeneousTree,
    Tree,
    TreeNodeListRepresentation,
    TreeNodeTupleRepresentation,
    TreeReferenceError,
)
from verysimpletree.tree import LeafValues


class AContent:
    def __init__(self, value: int):
        self.value = value


class BContent:
    def __init__(self, value: int):
        self.value = value


class A(Tree[Any]):
    def __init__(self, name: str, parent: "A | None" = None, *args: str, **kwargs: str):
        super().__init__(*args, **kwargs)
        self._children = []
        self._parent = parent
        self.name = name
        self.content = AContent(value=10)

    def _check_child_to_be_added(self, child: Any) -> bool:
        if not isinstance(child, Tree):
            raise TypeError
        return True

    def add_child_by_name(self, name: str) -> "A":
        child = self.__class__(name=name)
        super().add_child(child)
        return child

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r})"


class B(Tree[Any]):
    def __init__(self, name: str, *args: str, **kwargs: str):
        super().__init__(*args, **kwargs)
        self.name = name
        self.content = BContent(value=10)

    def _check_child_to_be_added(self, child: Any) -> bool:  # pragma: no cover
        if not isinstance(child, Tree):
            raise TypeError
        return True


class C(Tree[Any]):
    def __init__(self, name: str, value: int, *args: str, **kwargs: str):
        super().__init__(*args, **kwargs)
        self.name = name
        self.value = value

    def _check_child_to_be_added(self, child: Any) -> bool:  # pragma: no cover
        if not isinstance(child, Tree):
            raise TypeError
        return True


class IntegerTree(Tree["IntegerTree"]):
    def __init__(self, value: int) -> None:
        super().__init__()
        self.value = value

    def _check_child_to_be_added(self, child: "IntegerTree") -> bool:
        if not isinstance(child, IntegerTree):
            raise TypeError("Expected an IntegerTree node")
        return True


def _node_value(node: Tree[Any]) -> int:
    if not isinstance(node, IntegerTree):
        raise TypeError("Expected an IntegerTree node")
    return node.value


def test_get_layer_overload_types() -> None:
    root = IntegerTree(1)
    child = root.add_child(IntegerTree(2))

    assert assert_type(root.get_layer(1), Sequence[IntegerTree]) == [child]
    assert assert_type(root.get_layer(1, None), Sequence[IntegerTree]) == [child]
    assert assert_type(root.get_layer(1, key=None), Sequence[IntegerTree]) == [child]
    assert assert_type(
        root.get_layer(1, _node_value),
        Sequence[int],
    ) == [2]
    assert assert_type(
        root.get_layer(1, key=lambda node: str(node.value)), Sequence[str]
    ) == ["2"]


def test_get_self_with_key_overload_types() -> None:
    root = IntegerTree(1)

    assert assert_type(root.get_self_with_key(), IntegerTree) is root
    assert assert_type(root.get_self_with_key(None), IntegerTree) is root
    assert assert_type(root.get_self_with_key(key=None), IntegerTree) is root
    assert assert_type(root.get_self_with_key(_node_value), int) == 1
    assert (
        assert_type(root.get_self_with_key(key=lambda node: str(node.value)), str)
        == "1"
    )
    assert assert_type(root.get_self_with_key("value"), Any) == 1
    mixed_root = A("root")
    assert assert_type(mixed_root.get_self_with_key(), A) is mixed_root

    assert (
        assert_type(mixed_root.get_self_with_key(key=lambda node: node.name), str)
        == "root"
    )


def _node_name(node: Tree[Any]) -> str:
    if not isinstance(node, (A, B, C)):
        raise TypeError("Expected an A, B, or C node")
    return node.name


def _node_name_and_value(node: Tree[Any]) -> list[str | int]:
    if not isinstance(node, C):
        raise TypeError("Expected a C node")
    return [node.name, node.value]


class TreeTestCase(TestCase):
    def setUp(self) -> None:
        self.root = A(name="root")
        self.child1 = self.root.add_child_by_name("child1")
        self.child2 = self.root.add_child_by_name("child2")
        self.child3 = self.root.add_child_by_name("child3")
        self.child4 = self.root.add_child_by_name("child4")
        self.grandchild1 = self.child2.add_child_by_name("grandchild1")
        self.grandchild2 = self.child2.add_child_by_name("grandchild2")
        self.grandchild3 = self.child4.add_child_by_name("grandchild3")
        self.greatgrandchild1 = self.grandchild2.add_child_by_name("greatgrandchild1")


class Test(TreeTestCase):
    def test_is_last_child(self) -> None:
        t = self.root
        for node in t.traverse():
            if node.name in [
                "root",
                "child4",
                "grandchild2",
                "grandchild3",
                "greatgrandchild1",
            ]:
                assert node.is_last_child
            else:
                assert not node.is_last_child

    def test_is_first_child(self) -> None:
        t = self.root
        for node in t.traverse():
            if node.name in [
                "root",
                "child1",
                "grandchild1",
                "grandchild3",
                "greatgrandchild1",
            ]:
                assert node.is_first_child
            else:
                assert not node.is_first_child

    def test_get_root(self) -> None:
        assert self.greatgrandchild1.get_root() == self.root
        assert self.child4.get_root() == self.root
        assert self.root.get_root() == self.root

    def test_is_leaf(self) -> None:
        assert self.greatgrandchild1.is_leaf is True
        assert self.child4.is_leaf is False
        assert self.child3.is_leaf is True

    def test_traverse(self) -> None:
        assert list(self.root.traverse()) == [
            self.root,
            self.child1,
            self.child2,
            self.grandchild1,
            self.grandchild2,
            self.greatgrandchild1,
            self.child3,
            self.child4,
            self.grandchild3,
        ]

    def test_iterate_leaves(self) -> None:
        assert list(self.root.iterate_leaves()) == [
            self.child1,
            self.grandchild1,
            self.greatgrandchild1,
            self.child3,
            self.grandchild3,
        ]

    def test_level(self) -> None:
        assert [node.get_level() for node in self.root.traverse()] == [
            0,
            1,
            1,
            2,
            2,
            3,
            1,
            1,
            2,
        ]
        assert self.greatgrandchild1.get_level() == 3
        assert self.grandchild2.get_level() == 2
        assert self.child4.get_level() == 1
        assert self.root.get_level() == 0

    def test_reversed_path_to_root(self) -> None:
        assert list(self.greatgrandchild1.get_reversed_path_to_root()) == [
            self.greatgrandchild1,
            self.grandchild2,
            self.child2,
            self.root,
        ]

    def test_remove_child(self) -> None:
        with self.assertRaises(ChildNotFoundError):
            self.child2.remove(self.child1)

        self.child2.remove(self.grandchild2)
        assert self.child2.get_children() == [self.grandchild1]
        assert self.grandchild2.get_parent() is None
        assert self.greatgrandchild1.get_parent() == self.grandchild2

    def test_remove_last_child(self) -> None:
        assert list(self.child4.iterate_leaves()) == [self.grandchild3]

        self.child4.remove(self.grandchild3)

        assert self.child4.get_children() == []
        assert self.grandchild3.get_parent() is None
        assert self.child4.is_leaf is True
        assert list(self.child4.iterate_leaves()) == [self.child4]

    def test_remove_subtree_resets_cached_ancestor_paths(self) -> None:
        assert self.greatgrandchild1.get_reversed_path_to_root() == [
            self.greatgrandchild1,
            self.grandchild2,
            self.child2,
            self.root,
        ]

        self.child2.remove(self.grandchild2)

        assert self.grandchild2.get_parent() is None
        assert self.grandchild2.get_reversed_path_to_root() == [self.grandchild2]
        assert self.greatgrandchild1.get_reversed_path_to_root() == [
            self.greatgrandchild1,
            self.grandchild2,
        ]

    def test_add_child_rejects_attached_child(self) -> None:
        other_parent = A(name="other_parent")
        original_children = self.root.get_children()[:]

        with self.assertRaises(ValueError):
            other_parent.add_child(self.child2)

        assert self.root.get_children() == original_children
        assert self.child2.get_parent() is self.root
        assert other_parent.get_children() == []
        assert other_parent.is_leaf is True

    def test_add_child_rejects_duplicate(self) -> None:
        original_children = self.root.get_children()[:]

        with self.assertRaises(ValueError):
            self.root.add_child(self.child1)

        assert self.root.get_children() == original_children
        assert self.child1.get_parent() is self.root

    def test_add_child_accepts_detached_child(self) -> None:
        other_parent = A(name="other_parent")
        self.root.remove(self.child2)

        added_child = other_parent.add_child(self.child2)

        assert added_child is self.child2
        assert self.child2.get_parent() is other_parent
        assert self.child2 not in self.root.get_children()
        assert other_parent.get_children() == [self.child2]
        assert other_parent.is_leaf is False

    def test_add_child_rejects_self(self) -> None:
        root = A(name="root")

        with self.assertRaises(ValueError):
            root.add_child(root)

        assert root.get_parent() is None
        assert root.get_children() == []
        assert root.is_leaf is True

    def test_get_coordinates(self) -> None:
        assert self.greatgrandchild1.get_position_in_tree() == "2.2.1"
        assert self.child2.get_position_in_tree() == "2"
        assert self.root.get_position_in_tree() == "0"

    def test_replace_child(self) -> None:
        self.child2.replace_child(self.grandchild1, A(name="new_grand_child"))
        assert [ch.name for ch in self.child2.get_children()] == [
            "new_grand_child",
            "grandchild2",
        ]
        self.child1.add_child_by_name("grandchild")
        self.child1.add_child_by_name("grandchild")
        new = A(name="other_new_grand_child")
        self.child1.replace_child(lambda x: x.name == "grandchild", new, 1)
        assert new.get_parent() == self.child1
        assert [ch.name for ch in self.child1.get_children()] == [
            "grandchild",
            "other_new_grand_child",
        ]
        with self.assertRaises(ValueError):
            self.child2.replace_child(None, None)
        with self.assertRaises(TypeError):
            self.root.replace_child(self.child1, 34)

    def test_previous(self) -> None:
        assert self.child4.previous == self.child3
        assert self.child3.previous == self.child2
        assert self.child2.previous == self.child1
        assert self.child1.previous is None

    def test_next(self) -> None:
        assert self.child1.next == self.child2
        assert self.child2.next == self.child3
        assert self.child3.next == self.child4
        assert self.child4.next is None

    def test_get_leaves(self) -> None:
        assert self.root.get_leaves(key=lambda x: x.name) == [
            "child1",
            ["grandchild1", ["greatgrandchild1"]],
            "child3",
            ["grandchild3"],
        ]

    def test_get_layer(self) -> None:
        assert self.root.get_layer(0) == [self.root]
        assert self.root.get_layer(1) == [
            self.child1,
            self.child2,
            self.child3,
            self.child4,
        ]
        assert self.root.get_layer(2) == [
            self.child1,
            self.grandchild1,
            self.grandchild2,
            self.child3,
            self.grandchild3,
        ]
        assert self.root.get_layer(3) == [
            self.child1,
            self.grandchild1,
            self.greatgrandchild1,
            self.child3,
            self.grandchild3,
        ]
        assert self.root.get_layer(4) == [
            self.child1,
            self.grandchild1,
            self.greatgrandchild1,
            self.child3,
            self.grandchild3,
        ]

    def test_get_layers(self) -> None:
        assert self.root.get_number_of_layers() == 3
        assert self.root.get_layers()[0] == [self.root]
        assert self.root.get_layers()[1] == self.root.get_layer(1)
        assert self.root.get_layers()[2] == self.root.get_layer(2)
        assert self.root.get_layers()[3] == self.root.get_layer(3)

    def test_get_farthest_leaf(self) -> None:
        self.assertEqual(self.root.get_farthest_leaf(), self.greatgrandchild1)
        self.assertEqual(self.child1.get_farthest_leaf(), self.child1)
        self.assertEqual(self.child2.get_farthest_leaf(), self.greatgrandchild1)
        self.assertEqual(self.child3.get_farthest_leaf(), self.child3)
        self.assertEqual(self.child4.get_farthest_leaf(), self.grandchild3)
        self.assertEqual(self.grandchild2.get_farthest_leaf(), self.greatgrandchild1)

    def test_find_grandchild(self) -> None:
        assert [n for n in self.root.traverse() if n.get_level() == 2] == [
            self.grandchild1,
            self.grandchild2,
            self.grandchild3,
        ]
        for n in self.root.traverse():
            if n.get_level() == 2:
                print(n)
                break

    def test_content(self) -> None:
        self.child1.content.value = 20
        assert [ch.content.value for ch in self.root.get_children()] == [20, 10, 10, 10]

    def test_get_wrong_distance(self) -> None:
        with self.assertRaises(TreeReferenceError):
            assert (
                self.greatgrandchild1.get_distance(self.child1) == "bla"  # type: ignore
            )

    def test_get_distance(self) -> None:
        self.assertEqual(self.root.get_distance(self.root), 0)
        self.assertEqual(self.root.get_distance(self.child1), 1)
        self.assertEqual(self.root.get_distance(self.child2), 1)
        self.assertEqual(self.root.get_distance(self.child3), 1)
        self.assertEqual(self.root.get_distance(self.child4), 1)
        self.assertEqual(self.root.get_distance(self.grandchild1), 2)
        self.assertEqual(self.root.get_distance(self.grandchild2), 2)
        self.assertEqual(self.root.get_distance(self.grandchild3), 2)
        self.assertEqual(self.root.get_distance(self.greatgrandchild1), 3)

        self.assertEqual(self.child1.get_distance(self.child1), 0)
        self.assertEqual(self.child1.get_distance(self.root), 1)

        self.assertEqual(self.child2.get_distance(self.child2), 0)
        self.assertEqual(self.child2.get_distance(self.root), 1)
        self.assertEqual(self.child2.get_distance(self.grandchild1), 1)
        self.assertEqual(self.child2.get_distance(self.grandchild2), 1)
        self.assertEqual(self.child2.get_distance(self.greatgrandchild1), 2)

        self.assertEqual(self.child3.get_distance(self.child3), 0)
        self.assertEqual(self.child3.get_distance(self.root), 1)

        self.assertEqual(self.child4.get_distance(self.child4), 0)
        self.assertEqual(self.child4.get_distance(self.root), 1)
        self.assertEqual(self.child4.get_distance(self.grandchild3), 1)

    def test_get_farthest_leave_of_root_without_children(self) -> None:
        root = A("root")
        assert root.get_farthest_leaf() == root

    def test_get_leaves_of_root_without_children(self) -> None:
        root = A("root")
        assert root.get_leaves() == [root]
        assert root.get_leaves(key=lambda node: node.name) == ["root"]

    def test_get_number_of_layers_of_root_without_children(self) -> None:
        root = A("root")
        assert root.get_number_of_layers() == 0

    def test_get_layer_with_key(self) -> None:
        assert self.root.get_layer(1, lambda node: node.name) == [
            "child1",
            "child2",
            "child3",
            "child4",
        ]
        assert self.root.get_layer(2, lambda node: node.name) == [
            "child1",
            "grandchild1",
            "grandchild2",
            "child3",
            "grandchild3",
        ]
        assert self.root.get_layer(3, lambda node: node.name) == [
            "child1",
            "grandchild1",
            "greatgrandchild1",
            "child3",
            "grandchild3",
        ]

    def test_remove_children(self) -> None:
        self.root.remove_children()
        assert self.root.get_children() == []
        assert self.child1.name == "child1"

    def test_tree_representation_wrong_space(self) -> None:
        with self.assertRaises(TypeError):
            self.root.get_tree_representation(space=None)  # type: ignore
        with self.assertRaises(ValueError):
            self.root.get_tree_representation(space=0)

    def test_get_tree_representation(self) -> None:
        expected = """└── root
    ├── child1
    ├── child2
    │   ├── grandchild1
    │   └── grandchild2
    │       └── greatgrandchild1
    ├── child3
    └── child4
        └── grandchild3
"""

        assert self.root.get_tree_representation() == expected

    def test_get_number_of_layers(self) -> None:
        self.assertEqual(self.root.get_number_of_layers(), 3)
        self.assertEqual(self.child1.get_number_of_layers(), 0)
        self.assertEqual(self.child2.get_number_of_layers(), 2)
        self.assertEqual(self.child4.get_number_of_layers(), 1)
        self.assertEqual(self.grandchild1.get_number_of_layers(), 0)
        self.assertEqual(self.grandchild2.get_number_of_layers(), 1)
        self.assertEqual(self.greatgrandchild1.get_number_of_layers(), 0)


class TreeListRepresentationTestCase(TreeTestCase):
    def test_create_tree_from_typed_nested_integer_list(self) -> None:
        representation: TreeNodeListRepresentation[int] = [
            10,
            [3, [2, [1], [1]], [1]],
            [7, [4], [3, [2], [1]]],
        ]
        tree = IntegerTree.create_tree_from_list(representation, "value")
        assert tree.get_list_representation(key=_node_value) == representation
        assert [node.value for node in tree.traverse()] == [
            10,
            3,
            2,
            1,
            1,
            1,
            7,
            4,
            3,
            2,
            1,
        ]

    def test_create_tree_from_typed_integer_root(self) -> None:
        representation: TreeNodeListRepresentation[int] = [10]
        tree = IntegerTree.create_tree_from_list(representation, "value")
        assert tree.value == 10
        assert tree.is_leaf

    def test_create_tree_from_typed_nested_integer_tuple(self) -> None:
        representation: TreeNodeTupleRepresentation[int] = (
            10,
            (3, (2, (1,), (1,)), (1,)),
            (7, (4,), (3, (2,), (1,))),
        )
        tree = IntegerTree.create_tree_from_tuple(representation, "value")
        assert tree.get_tuple_representation(key=_node_value) == representation
        assert [node.value for node in tree.traverse()] == [
            10,
            3,
            2,
            1,
            1,
            1,
            7,
            4,
            3,
            2,
            1,
        ]

    def test_create_tree_from_typed_integer_root_tuple(self) -> None:
        representation: TreeNodeTupleRepresentation[int] = (10,)
        tree = IntegerTree.create_tree_from_tuple(representation, "value")
        assert tree.value == 10
        assert tree.is_leaf
        assert tree.get_tuple_representation(key=_node_value) == representation

    def test_create_tree_from_list_rejects_scalar_child(self) -> None:
        representation: TreeNodeListRepresentation[int] = [10, 3]
        with self.assertRaisesRegex(
            TypeError, "Each child representation must be a list"
        ):
            IntegerTree.create_tree_from_list(representation, "value")

    def test_create_tree_from_tuple_rejects_scalar_child(self) -> None:
        representation = (10, 3)
        with self.assertRaisesRegex(
            TypeError, "Each child representation must be a tuple"
        ):
            IntegerTree.create_tree_from_tuple(representation, "value")  # type: ignore[arg-type]

    def test_get_list_representation_all(self) -> None:
        assert self.root.get_list_representation(key=_node_name) == [
            "root",
            ["child1"],
            ["child2", ["grandchild1"], ["grandchild2", ["greatgrandchild1"]]],
            ["child3"],
            ["child4", ["grandchild3"]],
        ]

    def test_get_tuple_representation_all(self) -> None:
        assert self.root.get_tuple_representation(key=_node_name) == (
            "root",
            ("child1",),
            ("child2", ("grandchild1",), ("grandchild2", ("greatgrandchild1",))),
            ("child3",),
            ("child4", ("grandchild3",)),
        )

    def test_get_list_representation_only_root(self) -> None:
        a = A(name="root")
        assert a.get_list_representation(key=_node_name) == ["root"]

    def test_get_tuple_representation_only_root(self) -> None:
        a = A(name="root")
        assert a.get_tuple_representation(key=_node_name) == ("root",)

    def test_create_tree_from_list(self) -> None:
        tree = A.create_tree_from_list(
            self.root.get_list_representation(key=_node_name), "name"
        )
        assert tree.get_list_representation(
            key=_node_name
        ) == self.root.get_list_representation(key=_node_name)

    def test_create_tree_from_tuple(self) -> None:
        tree = A.create_tree_from_tuple(
            self.root.get_tuple_representation(key=_node_name), "name"
        )
        assert tree.get_tuple_representation(
            key=_node_name
        ) == self.root.get_tuple_representation(key=_node_name)

    def test_create_tree_from_list_only_root(self) -> None:
        tree = A.create_tree_from_list(
            self.root.get_list_representation(key=_node_name), ["name"]
        )
        assert tree.get_list_representation(
            key=_node_name
        ) == self.root.get_list_representation(key=_node_name)

    def test_create_tree_from_tuple_only_root(self) -> None:
        root = A(name="root")
        tree = A.create_tree_from_tuple(
            root.get_tuple_representation(key=_node_name), ["name"]
        )
        assert tree.get_tuple_representation(key=_node_name) == ("root",)
        assert tree.is_leaf

    def test_create_tree_from_list_with_name_and_value(self) -> None:
        def _copy_node(node: A, current_value: int) -> C:
            copied = C(name=node.name, value=current_value)
            current_value += 1
            for child in node.get_children():
                copied.add_child(_copy_node(child, current_value=current_value))
            return copied

        copied_c = _copy_node(self.root, 0)
        representation = copied_c.get_list_representation(key=_node_name_and_value)
        assert representation == [
            ["root", 0],
            [["child1", 1]],
            [
                ["child2", 1],
                [["grandchild1", 2]],
                [["grandchild2", 2], [["greatgrandchild1", 3]]],
            ],
            [["child3", 1]],
            [["child4", 1], [["grandchild3", 2]]],
        ]
        tree = C.create_tree_from_list(representation, ["name", "value"])
        assert tree.get_list_representation(
            key=_node_name_and_value
        ) == copied_c.get_list_representation(key=_node_name_and_value)

    def test_create_tree_from_tuple_with_name_and_value(self) -> None:
        def _copy_node(node: A, current_value: int) -> C:
            copied = C(name=node.name, value=current_value)
            current_value += 1
            for child in node.get_children():
                copied.add_child(_copy_node(child, current_value=current_value))
            return copied

        copied_c = _copy_node(self.root, 0)
        representation: TreeNodeTupleRepresentation[list[str | int]] = (
            copied_c.get_tuple_representation(key=_node_name_and_value)
        )
        assert representation == (
            ["root", 0],
            (["child1", 1],),
            (
                ["child2", 1],
                (["grandchild1", 2],),
                (["grandchild2", 2], (["greatgrandchild1", 3],)),
            ),
            (["child3", 1],),
            (["child4", 1], (["grandchild3", 2],)),
        )
        tree = C.create_tree_from_tuple(representation, ["name", "value"])
        assert tree.get_tuple_representation(key=_node_name_and_value) == representation

    def test_get_list_representation_mixed_types(self) -> None:
        root = A(name="root")
        child = root.add_child(B(name="child"))
        child.add_child(C(name="grandchild", value=2))
        assert root.get_list_representation(key=_node_name) == [
            "root",
            ["child", ["grandchild"]],
        ]

    def test_get_tuple_representation_mixed_types(self) -> None:
        root = A(name="root")
        child = root.add_child(B(name="child"))
        child.add_child(C(name="grandchild", value=2))
        assert root.get_tuple_representation(key=_node_name) == (
            "root",
            ("child", ("grandchild",)),
        )

    def test_get_list_representation_rejects_unsupported_child(self) -> None:
        root = C(name="root", value=0)
        root.add_child(A(name="child"))
        with self.assertRaisesRegex(TypeError, "Expected a C node"):
            root.get_list_representation(key=_node_name_and_value)

    def test_get_tuple_representation_rejects_unsupported_child(self) -> None:
        root = C(name="root", value=0)
        root.add_child(A(name="child"))
        with self.assertRaisesRegex(TypeError, "Expected a C node"):
            root.get_tuple_representation(key=_node_name_and_value)


class TestTreeMutations(TreeTestCase):
    def test_add_child_rejects_ancestor(self) -> None:
        original_nodes = list(self.root.traverse())

        with self.assertRaises(ValueError):
            self.greatgrandchild1.add_child(self.root)

        assert self.root.get_parent() is None
        assert self.greatgrandchild1.get_children() == []
        assert list(self.root.traverse()) == original_nodes

    def test_add_child_resets_cached_subtree_paths(self) -> None:
        subtree = A(name="subtree")
        descendant = subtree.add_child_by_name("descendant")
        assert descendant.get_reversed_path_to_root() == [descendant, subtree]

        self.child1.add_child(subtree)

        assert subtree.get_reversed_path_to_root() == [subtree, self.child1, self.root]
        assert descendant.get_reversed_path_to_root() == [
            descendant,
            subtree,
            self.child1,
            self.root,
        ]

    def test_insert_child_matches_list_indices(self) -> None:
        for index in (0, 1, 2, -1, -100, 100):
            with self.subTest(index=index):
                parent = A(name="parent")
                first = parent.add_child_by_name("first")
                last = parent.add_child_by_name("last")
                child = A(name="inserted")
                expected = [first, last]
                expected.insert(index, child)
                list(parent.traverse())

                assert parent.insert_child(index, child) is child

                assert list(parent.get_children()) == expected
                assert child.get_parent() is parent
                assert list(parent.traverse()) == [parent, *expected]

    def test_insert_child_resets_caches(self) -> None:
        subtree = A(name="subtree")
        descendant = subtree.add_child_by_name("descendant")
        assert descendant.get_reversed_path_to_root() == [descendant, subtree]
        original_nodes = list(self.root.traverse())
        original_leaves = list(self.root.iterate_leaves())

        self.child1.insert_child(0, subtree)

        assert self.child1.is_leaf is False
        assert list(self.root.traverse()) == [
            *original_nodes[:2],
            subtree,
            descendant,
            *original_nodes[2:],
        ]
        assert list(self.root.iterate_leaves()) == [descendant, *original_leaves[1:]]
        assert descendant.get_reversed_path_to_root() == [
            descendant,
            subtree,
            self.child1,
            self.root,
        ]

    def test_insert_child_rejects_invalid_attachment_without_mutation(self) -> None:
        original_nodes = list(self.root.traverse())
        for child, error in (
            (self.child1, ValueError),
            (self.greatgrandchild1, ValueError),
            (self.root, ValueError),
            (object(), TypeError),
        ):
            with self.subTest(child=child):
                with self.assertRaises(error):
                    self.greatgrandchild1.insert_child(0, child)

                assert self.greatgrandchild1.get_children() == []
                assert self.greatgrandchild1.is_leaf is True
                assert self.child1.get_parent() is self.root
                assert self.root.get_parent() is None
                assert list(self.root.traverse()) == original_nodes

    def test_insert_child_rejects_invalid_index_without_mutation(self) -> None:
        child = A(name="child")
        index: Any = "invalid"
        original_nodes = list(self.root.traverse())

        with self.assertRaises(TypeError):
            self.child1.insert_child(index, child)

        assert child.get_parent() is None
        assert self.child1.get_children() == []
        assert self.child1.is_leaf is True
        assert list(self.root.traverse()) == original_nodes

    def test_replace_child_resets_subtree_and_ancestor_caches(self) -> None:
        incoming = A(name="incoming")
        descendant = incoming.add_child_by_name("descendant")
        assert descendant.get_reversed_path_to_root() == [descendant, incoming]
        self.greatgrandchild1.get_reversed_path_to_root()
        original_nodes = list(self.root.traverse())
        list(self.root.iterate_leaves())

        self.child2.replace_child(self.grandchild2, incoming)

        assert self.child2.get_children() == [self.grandchild1, incoming]
        assert self.grandchild2.get_parent() is None
        assert incoming.get_parent() is self.child2
        assert list(self.root.traverse()) == [
            *original_nodes[:4],
            incoming,
            descendant,
            *original_nodes[6:],
        ]
        assert list(self.root.iterate_leaves()) == [
            self.child1,
            self.grandchild1,
            descendant,
            self.child3,
            self.grandchild3,
        ]
        assert self.greatgrandchild1.get_reversed_path_to_root() == [
            self.greatgrandchild1,
            self.grandchild2,
        ]
        assert descendant.get_reversed_path_to_root() == [
            descendant,
            incoming,
            self.child2,
            self.root,
        ]

    def test_replace_child_rejects_invalid_attachment_without_mutation(self) -> None:
        original_children = self.child2.get_children()[:]
        original_nodes = list(self.root.traverse())
        for child, error in (
            (self.child1, ValueError),
            (self.grandchild2, ValueError),
            (self.child2, ValueError),
            (self.root, ValueError),
            (object(), TypeError),
        ):
            with self.subTest(child=child):
                with self.assertRaises(error):
                    self.child2.replace_child(self.grandchild1, child)

                assert self.child2.get_children() == original_children
                assert self.grandchild1.get_parent() is self.child2
                assert self.grandchild2.get_parent() is self.child2
                assert self.child1.get_parent() is self.root
                assert self.root.get_parent() is None
                assert list(self.root.traverse()) == original_nodes

    def test_replace_child_with_itself_is_noop(self) -> None:
        original_children = self.root.get_children()[:]
        original_nodes = list(self.root.traverse())

        self.root.replace_child(self.child1, self.child1)

        assert self.root.get_children() == original_children
        assert self.child1.get_parent() is self.root
        assert list(self.root.traverse()) == original_nodes

    def test_replace_child_invalid_selection_leaves_new_child_detached(self) -> None:
        replacement = A(name="replacement")
        original_children = self.child2.get_children()[:]
        for old, index, error in (
            (self.child1, 0, ValueError),
            (self.grandchild1, 1, IndexError),
        ):
            with self.subTest(old=old, index=index):
                with self.assertRaises(error):
                    self.child2.replace_child(old, replacement, index)

                assert replacement.get_parent() is None
                assert self.child2.get_children() == original_children
                assert self.grandchild1.get_parent() is self.child2


class TestNodeReturnValue(TreeTestCase):
    def test_with_string(self) -> None:
        assert self.grandchild1.get_self_with_key(key="name") == "grandchild1"
        with self.assertRaises(AttributeError):
            self.grandchild1.get_self_with_key(key="wrong")

    def test_with_callable(self) -> None:
        assert (
            self.grandchild1.get_self_with_key(
                key=lambda node: node.get_position_in_tree()
            )
            == "2.1"
        )
        with self.assertRaises(AttributeError):
            self.grandchild1.get_self_with_key(key=lambda node: node.wrong_method())  # type: ignore

    def test_with_node(self) -> None:
        assert (
            self.grandchild1.get_self_with_key()
            == self.grandchild1.get_self_with_key(key=None)
            == self.grandchild1
        )

    def test_wrong_type(self) -> None:
        with self.assertRaises(TypeError):
            self.grandchild1.get_self_with_key(key=1)  # type: ignore


class TestTwoTypesOfChildren(TestCase):
    def setUp(self) -> None:
        self.root = A(name="root_a")
        self.ach1 = self.root.add_child(A(name="b_child_1"))
        self.bch1 = self.root.add_child(B(name="a_child_1"))
        self.ach2 = self.root.add_child(A(name="b_child_2"))
        self.bch2 = self.root.add_child(B(name="a_child_2"))

    def test_get_children_of_type(self) -> None:
        assert self.root.get_children() == [self.ach1, self.bch1, self.ach2, self.bch2]
        assert self.root.get_children_of_type(A) == [self.ach1, self.ach2]
        assert self.root.get_children_of_type(B) == [self.bch1, self.bch2]
        assert_type(self.root.get_children_of_type(A), Sequence[A])
        assert_type(self.root.get_children_of_type(B), Sequence[B])


class HA(HomogeneousTree):
    pass


class HB(HA):
    pass


class HC(HomogeneousTree):
    pass


def test_homogeneous_tree_specializes_children_and_descendants() -> None:
    tree = HB()
    child = tree.add_child(HB())
    grandchild = child.add_child(HB())

    assert_type(tree._children, list[HB])
    assert_type(tree.get_children(), Sequence[HB])  # noqa: F821
    assert_type(tree.get_children_of_type(HB), Sequence[HB])
    assert_type(tree._raw_traverse(), Iterator[HB])
    assert_type(tree.traverse(), Iterator[HB])
    assert_type(tree.iterate_leaves(), Iterator[HB])
    assert_type(tree.get_farthest_leaf(), HB)
    assert assert_type(tree.get_self_with_key(), HB) is tree
    assert assert_type(tree.get_self_with_key(key=None), HB) is tree
    assert assert_type(tree.get_self_with_key(lambda node: node.is_leaf), bool) is False
    assert assert_type(tree.get_self_with_key("is_leaf"), Any) is False
    assert assert_type(tree.get_layers(), Sequence[Sequence[HB]]) == [
        [tree],
        [child],
        [grandchild],
    ]
    assert assert_type(
        tree.get_layers(key=lambda node: node.is_leaf), Sequence[Sequence[bool]]
    ) == [[False], [False], [True]]
    assert assert_type(tree.get_leaves(), LeafValues[HB]) == [[grandchild]]
    assert assert_type(
        tree.get_leaves(key=lambda node: node.is_leaf), LeafValues[bool]
    ) == [[True]]
    assert assert_type(tree.get_layer(2), Sequence[HB]) == [grandchild]
    assert assert_type(tree.get_layer(2, None), Sequence[HB]) == [grandchild]
    assert assert_type(tree.get_layer(2, key=None), Sequence[HB]) == [grandchild]
    assert assert_type(
        tree.get_layer(2, lambda node: node.is_leaf),
        Sequence[bool],
    ) == [True]
    assert assert_type(
        tree.get_layer(2, key=lambda node: type(node).__name__), Sequence[str]
    ) == ["HB"]
    assert_type(
        tree.filter_nodes(lambda node: assert_type(node, HB).is_leaf, True),
        Sequence[HB],
    )

    assert tree.get_children() is tree._children
    assert tree.get_children() == [child]
    assert tree.get_children_of_type(HB) == [child]
    assert tree.get_children_of_type(HC) == []
    assert list(tree.traverse()) == [tree, child, grandchild]
    assert list(tree.iterate_leaves()) == [grandchild]
    assert tree.get_farthest_leaf() is grandchild
    assert tree.get_layer(2) == [grandchild]
    assert tree.get_leaves() == [[grandchild]]
    assert tree.get_self_with_key() is tree
    assert tree.filter_nodes(lambda node: node.is_leaf, True) == [grandchild]


def test_homogeneous_tree_can_add_child_of_its_type() -> None:
    tree = HA()
    child = tree.add_child(HA())
    assert tree.get_children()[0] is child
    assert child.up is tree


def test_homogeneous_tree_can_add_child_of_its_subtype() -> None:
    tree = HA()
    child = tree.add_child(HB())
    assert tree.get_children()[0] is child
    assert child.up is tree


def test_homogeneous_tree_narrows_children_to_requested_type() -> None:
    tree = HA()
    child = tree.add_child(HB())
    tree.add_child(HA())

    assert assert_type(tree.get_children_of_type(HB), Sequence[HB]) == [child]
    assert assert_type(tree.get_children_of_type(HC), Sequence[HC]) == []


@pytest.mark.parametrize("child_type", [HA, HB])
def test_homogeneous_tree_can_insert_child(child_type: type[HA]) -> None:
    tree = HA()
    existing = tree.add_child(HA())
    child = child_type()

    assert tree.insert_child(0, child) is child
    assert tree.get_children() == [child, existing]
    assert child.up is tree


@pytest.mark.parametrize("child_type", [HA, HB])
def test_homogeneous_tree_can_replace_child(child_type: type[HA]) -> None:
    tree = HA()
    old = tree.add_child(HA())
    child = child_type()
    assert list(tree.traverse()) == [tree, old]
    tree.replace_child(old, child)

    assert tree.get_children() == [child]
    assert child.up is tree
    assert old.up is None
    assert list(tree.traverse()) == [tree, child]


@pytest.mark.parametrize(("parent_type", "child_type"), [(HA, HC), (HB, HA), (HB, HC)])
@pytest.mark.parametrize("operation", ["add", "insert", "replace"])
def test_homogeneous_tree_rejects_invalid_child_without_mutation(
    parent_type: type[HA],
    child_type: type[HomogeneousTree],
    operation: str,
) -> None:
    tree = parent_type()
    existing = tree.add_child(parent_type())
    child = child_type()
    assert list(tree.traverse()) == [tree, existing]
    assert list(tree.iterate_leaves()) == [existing]
    assert existing.get_reversed_path_to_root() == [existing, tree]

    with pytest.raises(TypeError, match="accepts only children"):
        if operation == "add":
            tree.add_child(child)  # type: ignore[arg-type]
        elif operation == "insert":
            tree.insert_child(0, child)  # type: ignore[arg-type]
        else:
            tree.replace_child(existing, child)  # type: ignore[arg-type]

    assert tree.get_children() == [existing]
    assert existing.up is tree
    assert child.up is None
    assert not tree.is_leaf
    assert list(tree.traverse()) == [tree, existing]
    assert list(tree.iterate_leaves()) == [existing]
    assert existing.get_reversed_path_to_root() == [existing, tree]
