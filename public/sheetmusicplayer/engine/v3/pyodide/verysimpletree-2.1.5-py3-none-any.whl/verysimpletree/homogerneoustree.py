from typing import Any, Callable, Iterator, Self, Sequence, cast, overload

from verysimpletree.tree import (
    Tree,
    TreeNodeListRepresentation,
    TreeNodeTupleRepresentation,
    ValueT,
    LeafValues,
)


class HomogeneousTree(Tree[Any]):
    """Specialize downward queries; ancestors and siblings may have broader types.

    Casts bridge the base class's shared node type for downward-only operations,
    relying on the child-type invariant enforced by structural mutation methods.
    """

    _parent: Self | None
    _children: list[Self]
    _traversed: list[Self] | None
    _iterated_leaves: list[Self] | None
    _reversed_path_to_root: list[Self] | None

    def _check_child_to_be_added(self, child: Self) -> bool:
        if not isinstance(child, self.__class__):
            raise TypeError(
                f"{type(self).__name__} accepts only children "
                f"of its own type or subclasses"
            )
        return True

    def _raw_traverse(self) -> Iterator[Self]:
        return cast(Iterator[Self], super()._raw_traverse())

    def _raw_reversed_path_to_root(self) -> Iterator[Self]:
        return cast(Iterator[Self], super()._raw_reversed_path_to_root())

    def _validate_child_attachment(self, child: Self) -> None:
        return super()._validate_child_attachment(child)

    @property
    def next(self) -> Self | None:
        return cast(Self | None, super().next)

    @property
    def previous(self) -> Self | None:
        return cast(Self | None, super().previous)

    @property
    def up(self) -> Self | None:
        return cast(Self | None, super().up)

    def add_child(self, child: Self) -> Self:
        super().add_child(child)
        return child

    def insert_child(self, index: int, child: Self) -> Self:
        super().insert_child(index, child)
        return child

    @classmethod
    def create_tree_from_list(
        cls,
        tree_list_representation: TreeNodeListRepresentation[ValueT],
        represented_attribute_names: str | list[str],
    ) -> Self:
        return cast(
            Self,
            super().create_tree_from_list(
                tree_list_representation, represented_attribute_names
            ),
        )

    @classmethod
    def create_tree_from_tuple(
        cls,
        tree_tuple_representation: TreeNodeTupleRepresentation[ValueT],
        represented_attribute_names: str | list[str],
    ) -> Self:
        return cast(
            Self,
            super().create_tree_from_tuple(
                tree_tuple_representation, represented_attribute_names
            ),
        )

    def get_children(self) -> Sequence[Self]:
        return self._children

    def get_children_of_type(self, type_: type[ValueT]) -> Sequence[ValueT]:
        return [child for child in self._children if isinstance(child, type_)]

    def get_distance(self, reference: Self | None = None) -> int:
        return super().get_distance(reference)

    def get_farthest_leaf(self) -> Self:
        return cast(Self, super().get_farthest_leaf())

    @overload
    def get_layer(
        self, level: int, key: Callable[[Self], ValueT]
    ) -> Sequence[ValueT]: ...

    @overload
    def get_layer(self, level: int, key: None = None) -> Sequence[Self]: ...

    def get_layer(
        self, level: int, key: Callable[[Self], ValueT] | None = None
    ) -> Sequence[Self | ValueT]:
        return cast(
            Sequence[Self | ValueT],
            super().get_layer(
                level, cast(Callable[["HomogeneousTree"], ValueT] | None, key)
            ),
        )

    @overload
    def get_layers(
        self, key: Callable[[Self], ValueT]
    ) -> Sequence[Sequence[ValueT]]: ...
    @overload
    def get_layers(self, key: None = None) -> Sequence[Sequence[Self]]: ...

    def get_layers(
        self, key: Callable[[Self], ValueT] | None = None
    ) -> Sequence[Sequence[Self]] | Sequence[Sequence[ValueT]]:
        return cast(
            Sequence[Sequence[Self]] | Sequence[Sequence[ValueT]],
            super().get_layers(cast(Callable[["HomogeneousTree"], ValueT] | None, key)),
        )

    @overload
    def get_leaves(self, key: Callable[[Self], ValueT]) -> LeafValues[ValueT]: ...

    @overload
    def get_leaves(self, key: None = None) -> LeafValues[Self]: ...

    def get_leaves(
        self, key: Callable[[Self], ValueT] | None = None
    ) -> LeafValues[Self] | LeafValues[ValueT]:
        return cast(
            LeafValues[Self] | LeafValues[ValueT],
            super().get_leaves(cast(Callable[["HomogeneousTree"], ValueT] | None, key)),
        )

    def get_parent(self) -> Self | None:
        return self._parent

    def get_reversed_path_to_root(self) -> Sequence[Self]:
        return cast(Sequence[Self], super().get_reversed_path_to_root())

    @overload
    def get_self_with_key(self, key: Callable[[Self], ValueT]) -> ValueT: ...

    @overload
    def get_self_with_key(self, key: str) -> Any: ...

    @overload
    def get_self_with_key(self, key: None = None) -> Self: ...

    def get_self_with_key(
        self, key: str | Callable[[Self], ValueT] | None = None
    ) -> Any:
        return super().get_self_with_key(
            cast(str | Callable[["HomogeneousTree"], ValueT] | None, key)
        )

    def get_tree_representation(
        self, key: Callable[[Self], Any] | None = None, space: int = 3
    ) -> str:
        return super().get_tree_representation(
            cast(Callable[["HomogeneousTree"], Any] | None, key), space
        )

    def get_list_representation(
        self, key: Callable[[Self], ValueT]
    ) -> TreeNodeListRepresentation[ValueT]:
        return super().get_list_representation(cast(Callable[[Tree[Any]], ValueT], key))

    def get_root(self) -> Self:
        return cast(Self, super().get_root())

    def get_tuple_representation(
        self, key: Callable[[Self], ValueT]
    ) -> TreeNodeTupleRepresentation[ValueT]:
        return super().get_tuple_representation(
            cast(Callable[[Tree[Any]], ValueT], key)
        )

    def filter_nodes(
        self, key: Callable[[Self], Any], return_value: Any
    ) -> Sequence[Self]:
        return [node for node in self.traverse() if key(node) == return_value]

    def iterate_leaves(self) -> Iterator[Self]:
        return cast(Iterator[Self], super().iterate_leaves())

    def remove(self, child: Self) -> None:
        super().remove(child)

    def replace_child(
        self,
        old: Self | Callable[[Self], Any],
        new: Self,
        index: int = 0,
    ) -> None:
        super().replace_child(
            cast(HomogeneousTree | Callable[[HomogeneousTree], Any], old),
            new,
            index,
        )

    def traverse(self) -> Iterator[Self]:
        return cast(Iterator[Self], super().traverse())
